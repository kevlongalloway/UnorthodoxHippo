# Precis — Latest Iterations (March 2026)

## /builds/ — New and Substantially Updated
- precis-press.jsx (NEW) — The Press: Original Work discovery, Editor Picks, Trending, Browse by Tag, full theme system + platform nav
- precis-compose-v6.jsx (983 to 1151L) — Attestation, poetry mode, curated genre/mood tags, Inspired By, creator reference, local auto-save, rate limiting, rights language
- precis-feed-v8.jsx (743 to 794L) — Tag rendering, inspiration links, attestation badge, AI flag menu, The Press nav tab + cross-links

## /nav/ — Navigation-Updated Builds (The Press wired in)
15 files with The Press added to navigation:
PersistentNav.jsx, precis-shared-nav, precis-explore, precis-author, precis-book-clubs, precis-challenges, precis-messages, precis-notifications, precis-shelf, precis-book-community-v4, precis-book-detail, precis-mentions, precis-profile-v11, precis-settings, precis-synopsis-engine

## /deck/
- Precis_CTO_Pitch_v2.pptx — 12-slide CTO pitch, 5%+5% Technologies equity

## /legal/
- Precis_Legal_Suite_For_Review.zip — 11 documents for attorney review
